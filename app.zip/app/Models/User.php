<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',  // ✅ ditambahkan
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'role' => 'string', // ✅ pastikan role dibaca sebagai string
        ];
    }

    // ============================
    // 🔥 Helper untuk peran pengguna
    // ============================

    /**
     * Cek apakah user adalah owner.
     */
    public function isOwner()
    {
        return $this->role === 'owner';
    }

    /**
     * Cek apakah user adalah karyawan.
     */
    public function isEmployee()
    {
        return $this->role === 'employee';
    }
}
