<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Transaction extends Model
{
    use HasFactory;

    /**
     * Kolom yang dapat diisi secara massal
     */
    protected $fillable = [
        'code',
        'total',
        'customer_name',
        'order_type',
        'payment_method',
        'status',
        'note',
        'cancellation_reason',
        'cancelled_at',
    ];

    /**
     * Relasi ke tabel transaction_items
     */
    public function items()
    {
        return $this->hasMany(TransactionItem::class, 'transaction_id', 'id');
    }

    /**
     * Akses atribut untuk format tanggal pembatalan
     */
    public function getCancelledAtFormattedAttribute()
    {
        return $this->cancelled_at
            ? Carbon::parse($this->cancelled_at)->format('d-m-Y H:i')
            : null;
    }

    /**
     * Scope untuk memfilter transaksi aktif (tidak dibatalkan)
     */
    public function scopeActive($query)
    {
        return $query->where('status', '!=', 'cancelled');
    }

    /**
     * Scope untuk memfilter transaksi hari ini
     */
    public function scopeToday($query)
    {
        return $query->whereDate('created_at', Carbon::today());
    }
}
