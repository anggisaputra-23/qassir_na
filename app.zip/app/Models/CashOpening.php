<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CashOpening extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'opening_amount',
        'date',
        'shift_number',
    ];

    protected $casts = [
        'date' => 'datetime',
    ];

    public $timestamps = true;

    // Kasir yang membuka kas
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    // Relasi ke closing — HAS ONE
    public function cashClosing()
    {
        return $this->hasOne(CashClosing::class, 'cash_opening_id');
    }
}
