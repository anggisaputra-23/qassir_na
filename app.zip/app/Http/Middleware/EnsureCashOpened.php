<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\CashOpening;

class EnsureCashOpened
{
    public function handle($request, Closure $next)
    {
        $routeName = $request->route() ? $request->route()->getName() : null;

        if (!$routeName) {
            return $next($request);
        }

        $allowedRoutes = [
            // Dashboard
            'dashboard',
            'dashboard.index',

            // Kasir (buka kas)
            'kas.opening.form',
            'kas.opening.store',

            // Kasir (riwayat & print)
            'kas.history',
            'kas.print',
            'kas.detail',

            // Alias lama (biar kompatibel)
            'cash.opening.form',
            'cash.opening.store',
            'cash.history',
            'cash.print',
            'cash.show',
        ];

        if (in_array($routeName, $allowedRoutes)) {
            return $next($request);
        }

        // Cek kas aktif
        $activeOpening = CashOpening::whereDoesntHave('cashClosing')->first();

        if (!$activeOpening) {
            return redirect()->route('kas.opening.form')
                ->with('error', 'Silakan buka kasir terlebih dahulu sebelum melakukan transaksi.');
        }

        return $next($request);
    }
}
