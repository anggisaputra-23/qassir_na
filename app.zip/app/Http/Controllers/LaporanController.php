<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaction;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class LaporanController extends Controller
{
    /**
     * Laporan Harian
     */
    public function harian()
    {
        $today = Carbon::today();

        $data = Transaction::select(
            DB::raw('HOUR(created_at) as jam'),
            DB::raw('SUM(total) as pendapatan')
        )
        ->whereDate('created_at', $today)
        ->groupBy(DB::raw('HOUR(created_at)'))
        ->orderBy(DB::raw('HOUR(created_at)'))
        ->get();

        $labels = $data->pluck('jam')->map(fn($h) => sprintf('%02d:00', (int) $h));
        $values = $data->pluck('pendapatan')->map(fn($v) => (float) $v);

        return view('laporan.harian', compact('labels', 'values'));
    }

    /**
     * Laporan Bulanan
     */
    public function bulanan()
    {
        $month = Carbon::now()->month;
        $year  = Carbon::now()->year;

        $data = Transaction::select(
            DB::raw('DAY(created_at) as hari'),
            DB::raw('SUM(total) as pendapatan')
        )
        ->whereMonth('created_at', $month)
        ->whereYear('created_at', $year)
        ->groupBy(DB::raw('DAY(created_at)'))
        ->orderBy(DB::raw('DAY(created_at)'))
        ->get();

        $labels = $data->pluck('hari')->map(fn($d) => 'Tgl ' . (int) $d);
        $values = $data->pluck('pendapatan')->map(fn($v) => (float) $v);

        return view('laporan.bulanan', compact('labels', 'values'));
    }

    /**
     * Laporan Tahunan
     */
    public function tahunan()
    {
        $year = Carbon::now()->year;

        $data = Transaction::select(
            DB::raw('MONTH(created_at) as bulan'),
            DB::raw('SUM(total) as pendapatan')
        )
        ->whereYear('created_at', $year)
        ->groupBy(DB::raw('MONTH(created_at)'))
        ->orderBy(DB::raw('MONTH(created_at)'))
        ->get();

        $labels = $data->pluck('bulan')->map(fn($m) =>
            Carbon::createFromDate($year, (int) $m, 1)->translatedFormat('F')
        );
        $values = $data->pluck('pendapatan')->map(fn($v) => (float) $v);

        return view('laporan.tahunan', compact('labels', 'values'));
    }
}
