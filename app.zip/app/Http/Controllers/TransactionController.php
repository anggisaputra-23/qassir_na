<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Transaction;
use App\Models\TransactionItem;
use App\Models\CashSession; // ✅ Tambahan jika kamu punya model kas harian
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class TransactionController extends Controller
{
    // =========================
    // HALAMAN TRANSAKSI UTAMA
    // =========================
    public function index()
    {
        $products = Product::orderBy('name', 'asc')->get();
        $cart = Session::get('cart', []);
        $cartDiscount = Session::get('cart_discount', ['value' => 0, 'type' => 'nominal']);
        $cartOrderInfo = Session::get('cart_order_info', ['customer_name' => '', 'order_type' => 'dine_in']);
        $openBills = Session::get('open_bills', []);

        return view('transactions.index', compact('products', 'cart', 'cartDiscount', 'cartOrderInfo', 'openBills'));
    }

    // =========================
    // KERANJANG
    // =========================
    public function addToCart(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $cart = Session::get('cart', []);

        // ✅ Cek stok sebelum menambah ke keranjang
        if ($product->has_stock && $product->stock <= 0) {
            return response()->json(['success' => false, 'message' => 'Stok produk ini habis!'], 400);
        }

        if (isset($cart[$id])) {
            // Jika punya stok, pastikan tidak melebihi stok tersedia
            if ($product->has_stock && $cart[$id]['quantity'] >= $product->stock) {
                return response()->json(['success' => false, 'message' => 'Stok tidak mencukupi!'], 400);
            }
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                'name'          => $product->name,
                'price'         => (float) $product->price,
                'quantity'      => 1,
                'note'          => '',
                'discount'      => 0,
                'discount_type' => 'nominal'
            ];
        }

        Session::put('cart', $cart);
        $rawTotal = $this->calculateTotal($cart, Session::get('cart_discount', null));

        return $request->ajax()
            ? response()->json([
                'success'   => true,
                'cart'      => $cart,
                'total'     => $this->formatMoney($rawTotal),
                'raw_total' => $rawTotal
            ])
            : back()->with('success', "{$product->name} ditambahkan ke keranjang!");
    }

    public function removeFromCart(Request $request, $id)
    {
        $cart = Session::get('cart', []);
        if (isset($cart[$id])) unset($cart[$id]);
        empty($cart) ? Session::forget('cart') : Session::put('cart', $cart);

        $total = $this->calculateTotal($cart, Session::get('cart_discount', null));
        return response()->json([
            'success'   => true,
            'cart'      => $cart,
            'total'     => $this->formatMoney($total),
            'raw_total' => $total
        ]);
    }

    public function updateCart(Request $request)
    {
        $cart = Session::get('cart', []);
        $id = $request->id ?? null;

        if ($id && isset($cart[$id])) {
            $product = Product::find($id);
            if ($product && $product->has_stock && $request->quantity > $product->stock) {
                return response()->json(['success' => false, 'message' => 'Stok tidak mencukupi!'], 400);
            }

            $cart[$id]['quantity']      = max(1, (int)($request->quantity ?? $cart[$id]['quantity']));
            $cart[$id]['note']          = $request->note ?? $cart[$id]['note'];
            $cart[$id]['discount']      = max(0, (float)($request->discount ?? $cart[$id]['discount']));
            $cart[$id]['discount_type'] = in_array($request->discount_type, ['percent', 'nominal'])
                ? $request->discount_type
                : $cart[$id]['discount_type'];
        }

        if ($request->filled('discount_value') && $request->filled('discount_type')) {
            $type = in_array($request->discount_type, ['percent', 'nominal']) ? $request->discount_type : 'nominal';
            Session::put('cart_discount', [
                'value' => max(0, (float)$request->discount_value),
                'type'  => $type
            ]);
        }

        if ($request->filled('customer_name') && $request->filled('order_type')) {
            Session::put('cart_order_info', [
                'customer_name' => $request->customer_name,
                'order_type'    => in_array($request->order_type, ['dine_in', 'take_away']) ? $request->order_type : 'dine_in'
            ]);
        }

        Session::put('cart', $cart);
        $rawTotal = $this->calculateTotal($cart, Session::get('cart_discount', null));

        return response()->json([
            'success'       => true,
            'cart'          => $cart,
            'total'         => $this->formatMoney($rawTotal),
            'raw_total'     => $rawTotal,
            'itemSubtotal'  => $id && isset($cart[$id]) ? $this->formatMoney($this->calculateItemSubtotal($cart[$id])) : null
        ]);
    }

    private function calculateItemSubtotal($item)
    {
        $price = (float)($item['price'] ?? 0);
        $qty = (int)($item['quantity'] ?? 1);
        $discount = max(0, (float)($item['discount'] ?? 0));
        $discountType = $item['discount_type'] ?? 'nominal';

        $subtotal = $price * $qty;
        if ($discount > 0) {
            $subtotal -= ($discountType === 'percent') ? ($subtotal * $discount / 100) : $discount;
        }

        return max(0, round($subtotal, 2));
    }

    private function calculateTotal($cart = null, $discount = null)
    {
        $cart = $cart ?? Session::get('cart', []);
        $discount = $discount ?? Session::get('cart_discount', ['value' => 0, 'type' => 'nominal']);
        $subtotal = collect($cart)->sum(fn($item) => $this->calculateItemSubtotal($item));
        $total = $subtotal;

        if (!empty($discount) && isset($discount['value'])) {
            $val = max(0, (float)$discount['value']);
            $type = $discount['type'] ?? 'nominal';
            $total -= ($type === 'percent') ? ($total * $val / 100) : $val;
        }

        return max(0, round($total, 2));
    }

    private function formatMoney($amount)
    {
        return 'Rp ' . number_format($amount, 0, ',', '.');
    }

    // =========================
    // CHECKOUT (Kurangi stok)
    // =========================
    public function checkout(Request $request)
    {
        $cart = $request->cart ?? Session::get('cart', []);
        if (empty($cart)) {
            return response()->json(['success' => false, 'message' => 'Keranjang masih kosong!'], 422);
        }

        $discount = $request->discount ?? Session::get('cart_discount', ['value' => 0, 'type' => 'nominal']);
        $orderInfo = [
            'customer_name'   => $request->customer_name ?? (Session::get('cart_order_info.customer_name') ?? ''),
            'order_type'      => $request->order_type ?? (Session::get('cart_order_info.order_type') ?? 'dine_in'),
        ];

        $paymentMethod = $request->payment_method ?? 'cash';

        return DB::transaction(function () use ($cart, $discount, $orderInfo, $paymentMethod) {
            $total = $this->calculateTotal($cart, $discount);

            $transaction = Transaction::create([
                'code'           => uniqid(),
                'total'          => $total,
                'customer_name'  => $orderInfo['customer_name'],
                'order_type'     => $orderInfo['order_type'],
                'payment_method' => $paymentMethod,
                'status'         => 'paid',
                'discount_value' => $discount['value'] ?? 0,
                'discount_type'  => $discount['type'] ?? 'nominal'
            ]);

            $totalSubtotal = collect($cart)->sum(fn($item) => $this->calculateItemSubtotal($item));

            foreach ($cart as $id => $item) {
                $itemSubtotal = $this->calculateItemSubtotal($item);
                $product = Product::find($id);

                // Hitung pembagian diskon
                if (!empty($discount) && $discount['value'] > 0) {
                    if ($discount['type'] === 'percent') {
                        $itemSubtotal = $itemSubtotal * (1 - $discount['value'] / 100);
                    } else {
                        $proporsi = $itemSubtotal / $totalSubtotal;
                        $itemSubtotal = $itemSubtotal - ($discount['value'] * $proporsi);
                    }
                }

                TransactionItem::create([
                    'transaction_id' => $transaction->id,
                    'product_id'     => $id,
                    'quantity'       => $item['quantity'],
                    'price'          => $item['price'],
                    'subtotal'       => round($itemSubtotal, 2),
                    'note'           => $item['note'] ?? null,
                    'discount'       => $item['discount'] ?? 0,
                    'discount_type'  => $item['discount_type'] ?? 'nominal',
                ]);

                // ✅ Kurangi stok
                if ($product && $product->has_stock && $product->stock !== null) {
                    $product->decrement('stock', $item['quantity']);
                }
            }

            Session::forget(['cart', 'cart_discount', 'cart_order_info']);

            return response()->json([
                'success'         => true,
                'transaction_id'  => $transaction->id,
                'total'           => $total,
                'formatted_total' => $this->formatMoney($total),
                'payment_method'  => $transaction->payment_method
            ]);
        });
    }

    // =========================
    // PEMBATALAN TRANSAKSI (Restore stok)
    // =========================
    public function cancelTransaction(Request $request, $id)
    {
        $request->validate(['reason' => 'required|string|max:255']);
        $transaction = Transaction::with('items.product')->findOrFail($id);

        if ($transaction->status === 'cancelled') {
            return back()->with('error', 'Transaksi ini sudah dibatalkan.');
        }

        if ($transaction->created_at->toDateString() !== now()->toDateString()) {
            return back()->with('error', 'Transaksi hanya bisa dibatalkan di hari yang sama.');
        }

        // ✅ Kembalikan stok produk
        foreach ($transaction->items as $item) {
            $product = $item->product;
            if ($product && $product->has_stock && $product->stock !== null) {
                $product->increment('stock', $item->quantity);
            }
        }

        $transaction->update([
            'status'        => 'cancelled',
            'cancel_reason' => $request->reason,
            'cancelled_at'  => now(),
        ]);

        return redirect()->route('riwayat.index')->with('success', 'Transaksi berhasil dibatalkan dan stok dikembalikan.');
    }

    // =========================
    // HISTORY & OPEN BILL (tidak diubah)
    // =========================
    public function history(Request $request)
    {
        $query = Transaction::with('items.product')->orderBy('created_at', 'desc');

        if ($request->filled('tanggal_awal') && $request->filled('tanggal_akhir')) {
            $query->whereBetween('created_at', [
                $request->tanggal_awal . ' 00:00:00',
                $request->tanggal_akhir . ' 23:59:59',
            ]);
        }

        if ($request->filled('quick')) {
            switch ($request->quick) {
                case 'today': $query->whereDate('created_at', today()); break;
                case 'week': $query->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()]); break;
                case 'month': $query->whereMonth('created_at', now()->month)->whereYear('created_at', now()->year); break;
            }
        }

        if ($request->filled('payment_method')) {
            if ($request->payment_method === 'cash') $query->where('payment_method', 'cash');
            elseif ($request->payment_method === 'non_tunai')
                $query->whereNotNull('payment_method')->where('payment_method', '!=', 'cash');
        }

        $transactions = $query->get();

        $riwayatPerHari = $transactions->groupBy(fn($trx) => $trx->created_at->format('Y-m-d'))
            ->map(fn($transaksis, $tanggal) => [
                'tanggal'      => Carbon::parse($tanggal)->translatedFormat('l, d F Y'),
                'total_harian' => $transaksis->where('status', '!=', 'cancelled')->sum('total'),
                'transaksis'   => $transaksis
            ]);

        return view('transactions.history', compact('riwayatPerHari'));
    }

    public function show($id)
    {
        $transaction = Transaction::with('items.product')->findOrFail($id);
        return view('transactions.show', compact('transaction'));
    }

    // =========================
    // OPEN BILL (tidak diubah)
    // =========================
    public function saveOpenBill(Request $request)
    {
        $cart = $request->cart ?? Session::get('cart', []);
        if (empty($cart)) {
            return response()->json(['success' => false, 'message' => 'Keranjang kosong!'], 422);
        }

        $discountData = [
            'value' => max(0, (float)($request->discount_value ?? 0)),
            'type'  => in_array($request->discount_type, ['percent', 'nominal']) ? $request->discount_type : 'nominal'
        ];

        $total = $this->calculateTotal($cart, $discountData);

        $openBillData = [
            'id'            => uniqid(),
            'cart'          => $cart,
            'customer_name' => $request->customer_name ?? '',
            'order_type'    => in_array($request->order_type, ['dine_in', 'take_away']) ? $request->order_type : 'dine_in',
            'discount_value'=> $discountData['value'],
            'discount_type' => $discountData['type'],
            'total'         => $total,
            'created_at'    => now()->toDateTimeString()
        ];

        $openBills = Session::get('open_bills', []);
        $openBills[] = $openBillData;
        Session::put('open_bills', $openBills);
        Session::forget(['cart', 'cart_discount', 'cart_order_info']);

        return response()->json(['success' => true, 'bill' => $openBillData]);
    }

    public function getOpenBills()
    {
        return response()->json(array_values(Session::get('open_bills', [])));
    }

    public function loadOpenBill($id)
    {
        $openBills = Session::get('open_bills', []);
        foreach ($openBills as $key => $bill) {
            if ($bill['id'] == $id) {
                unset($openBills[$key]);
                Session::put('open_bills', array_values($openBills));

                Session::put('cart', $bill['cart']);
                Session::put('cart_discount', [
                    'value' => $bill['discount_value'] ?? 0,
                    'type'  => $bill['discount_type'] ?? 'nominal'
                ]);
                Session::put('cart_order_info', [
                    'customer_name' => $bill['customer_name'] ?? '',
                    'order_type'    => $bill['order_type'] ?? 'dine_in'
                ]);

                return response()->json(['success' => true, 'bill' => $bill]);
            }
        }

        return response()->json(['success' => false, 'message' => 'Open Bill tidak ditemukan!'], 404);
    }

    public function deleteOpenBill($id)
    {
        $openBills = Session::get('open_bills', []);
        foreach ($openBills as $key => $bill) {
            if ($bill['id'] == $id) {
                unset($openBills[$key]);
                Session::put('open_bills', array_values($openBills));
                return response()->json(['success' => true]);
            }
        }
        return response()->json(['success' => false], 404);
    }
}
