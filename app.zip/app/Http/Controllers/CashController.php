<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CashOpening;
use App\Models\CashClosing;
use App\Models\Expense;
use App\Models\Transaction;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CashController extends Controller
{
    // ======================
    // FORM OPENING (Kas Awal)
    // ======================
    public function openingForm()
    {
        return view('cash.opening');
    }

    public function saveOpening(Request $request)
    {
        $request->validate([
            'opening_amount' => 'required|numeric|min:0',
        ]);

        // Cek apakah masih ada shift aktif yang belum ditutup
        $activeShift = CashOpening::whereDoesntHave('cashClosing')->latest('date')->first();
        if ($activeShift) {
            return redirect()->route('dashboard.index')
                ->with('error', 'Masih ada shift aktif. Tutup kasir dulu sebelum membuka kas baru.');
        }

        // Hitung shift keberapa hari ini
        $today = now()->toDateString();
        $todayShifts = CashOpening::whereDate('date', $today)->count();
        $shiftNumber = $todayShifts + 1;

        // Simpan kas awal baru
        CashOpening::create([
            'user_id'        => Auth::id(),
            'opening_amount' => $request->opening_amount,
            'date'           => now(),
            'shift_number'   => $shiftNumber,
        ]);

        return redirect()->route('dashboard.index')->with(
            'success',
            "Shift {$shiftNumber} berhasil dibuka dengan kas awal sebesar Rp " .
            number_format($request->opening_amount, 0, ',', '.')
        );
    }

    // ======================
    // FORM CLOSING (Tutup Kasir)
    // ======================
    public function closingForm()
    {
        // Ambil kas yang belum ditutup
        $opening = CashOpening::whereDoesntHave('cashClosing')->latest('date')->first();

        if (!$opening) {
            return redirect()->route('cash.opening.form')
                ->with('error', 'Belum ada shift aktif. Harap buka kasir terlebih dahulu.');
        }

        // Ambil transaksi sejak kas awal (hanya yang 'paid')
        $transactions = Transaction::where('status', 'paid')
            ->where('created_at', '>=', $opening->date)
            ->get();

        if ($transactions->isEmpty()) {
            return redirect()->route('dashboard.index')
                ->with('error', 'Belum ada transaksi sejak kas awal. Tidak bisa tutup kasir.');
        }

        $totalSales     = $transactions->sum('total');
        $totalCash      = $transactions->where('payment_method', 'cash')->sum('total');
        $totalNonCash   = $transactions->where('payment_method', '!=', 'cash')->sum('total');
        $totalExpenses  = Expense::where('date', '>=', $opening->date)->sum('amount');

        // Expected cash = kas awal + total transaksi tunai - pengeluaran
        $expectedCash   = $opening->opening_amount + $totalCash - $totalExpenses;

        return view('cash.closing', compact(
            'totalSales',
            'totalCash',
            'totalNonCash',
            'totalExpenses',
            'expectedCash',
            'opening'
        ));
    }

    // ======================
    // SIMPAN CLOSING (Tutup Kasir)
    // ======================
    public function saveClosing(Request $request)
    {
        $request->validate([
            'actual_cash'             => 'required|numeric|min:0',
            'expenses.*.expense_name' => 'nullable|string|max:255',
            'expenses.*.amount'       => 'nullable|numeric|min:0',
        ]);

        try {
            DB::transaction(function () use ($request) {
                $opening = CashOpening::whereDoesntHave('cashClosing')->latest('date')->first();

                if (!$opening) {
                    throw new \Exception('Tidak ada shift aktif untuk ditutup.');
                }

                $transactions = Transaction::where('status', 'paid')
                    ->where('created_at', '>=', $opening->date)
                    ->get();

                if ($transactions->isEmpty()) {
                    throw new \Exception('Tidak ada transaksi sejak kas awal. Closing dibatalkan.');
                }

                // Simpan pengeluaran tambahan
                if ($request->has('expenses')) {
                    foreach ($request->expenses as $exp) {
                        if (!empty($exp['expense_name']) && !empty($exp['amount'])) {
                            Expense::create([
                                'expense_name' => $exp['expense_name'],
                                'amount'       => $exp['amount'],
                                'date'         => now(),
                                'user_id'      => Auth::id(),
                            ]);
                        }
                    }
                }

                // Hitung total transaksi dan pengeluaran
                $totalSales     = $transactions->sum('total');
                $totalCash      = $transactions->where('payment_method', 'cash')->sum('total');
                $totalNonCash   = $transactions->where('payment_method', '!=', 'cash')->sum('total');
                $totalExpenses  = Expense::where('date', '>=', $opening->date)->sum('amount');

                // Hitung expected cash
                $expectedCash = $opening->opening_amount + $totalCash - $totalExpenses;

                // Hitung selisih kas
                // Total kas fisik di laci = kas awal + input tunai tambahan dari user
                $totalCashFisik = $opening->opening_amount + $request->actual_cash;
                $difference     = $totalCashFisik - $expectedCash;

                // Simpan closing
                CashClosing::create([
                    'user_id'         => Auth::id(),
                    'cash_opening_id' => $opening->id,
                    'opening_amount'  => $opening->opening_amount,
                    'total_sales'     => $totalSales,
                    'total_cash'      => $totalCash,
                    'total_non_cash'  => $totalNonCash,
                    'total_expenses'  => $totalExpenses,
                    'expected_cash'   => $expectedCash,
                    'actual_cash'     => $request->actual_cash,
                    'difference'      => $difference,
                    'shift_number'    => $opening->shift_number,
                    'date'            => now(),
                ]);
            });

            return redirect()->route('cash.opening.form')
                ->with('success', 'Shift berhasil ditutup. Silakan masukkan kas awal baru untuk shift berikutnya.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    // ======================
    // CETAK REKAP KAS
    // ======================
    public function print($id)
    {
        $closing = CashClosing::with('user', 'opening')->find($id);

        if (!$closing || !$closing->opening) {
            return redirect()->route('cash.history')->with('error', 'Data kasir tidak ditemukan.');
        }

        $opening  = $closing->opening;
        $expenses = Expense::whereBetween('date', [$opening->date, $closing->date])->get();

        return view('cash.print', compact('closing', 'expenses'));
    }

    // ======================
    // RIWAYAT CLOSING
    // ======================
    public function history(Request $request)
    {
        $query = CashClosing::with('user')->orderBy('date', 'desc');

        if ($request->filled('kasir')) {
            $query->whereHas('user', function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->kasir . '%');
            });
        }

        if ($request->filled('tanggal_mulai') && $request->filled('tanggal_selesai')) {
            $start = Carbon::parse($request->tanggal_mulai)->startOfDay();
            $end   = Carbon::parse($request->tanggal_selesai)->endOfDay();
            $query->whereBetween('date', [$start, $end]);
        }

        $closings = $query->paginate(10)->appends($request->all());

        return view('cash.history', compact('closings'));
    }
}
